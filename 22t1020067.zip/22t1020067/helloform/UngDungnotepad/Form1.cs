﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UngDungnotepad
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btndocnoidung_Click(object sender, EventArgs e)
        {
            // Đọc file và hiển thị nội dung lên textbox
            String filename = "D:\\22t1020067\\BaiKiemTraSo1\\BaiKiemTraSo1\\sinhvien.txt";
            //filename = txtDuongDan.Text;
            DialogResult result = dlgOpen.ShowDialog();
            if (result == DialogResult.OK)
            {
                filename = dlgOpen.FileName;

                if (System.IO.File.Exists(filename))
                {
                    txtNoiDung.Text = System.IO.File.ReadAllText(filename);
                }
                else
                {
                    MessageBox.Show("Không thể truy xuất file " + filename, "Chú ý", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            
        }

        private void tsbthoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
