﻿namespace Xulyfile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            HienThiNoiDungFile();
        }

        private static void HienThiNoiDungFile()
        {
            String filename;
            filename = "D:\\dotNET-C4\\HelloClass\\NhanVien.cs";
            filename = "D:\\haha\\ngay3\\Xulyfile\\filetext.txt";

            StreamReader sr = new StreamReader(filename);

            while (true)
            {
                String line = sr.ReadLine();
                if (line == null)
                    break;

                Console.WriteLine(line);
            }

            sr.Close();
        }
    }
}
