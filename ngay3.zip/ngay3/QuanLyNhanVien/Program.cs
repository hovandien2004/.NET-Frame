﻿using System.Collections.Generic;

namespace QuanLyNhanVien
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<NhanVien> ds = new List<NhanVien>();
            string filename = "D:\\haha\\ngay3\\QuanLyNhanVien\\fileNhanVien.txt";
            StreamReader sr = new StreamReader(filename);
            while (true)
            {
                string line = sr.ReadLine();
                if (line == null)
                    break;

                string[] ok = line.Split(',');
                string maNhanVien = ok[0];
                string tenNhanVien = ok[1];
                bool gioiTinh = ok[2] == "True";
                DateTime ngaySinh = DateTime.ParseExact(ok[3],"d/M/yyyy", null);
                double heSoLuong = double.Parse(ok[4]);

                NhanVien nv = new NhanVien(maNhanVien, tenNhanVien, gioiTinh, ngaySinh, heSoLuong);
                ds.Add(nv);
            }
            sr.Close();
            
            for (int i = 0; i < ds.Count - 1; i++)
                for (int j = i + 1; j < ds.Count; j++)
                    if (ds[i].TenNhanVien.CompareTo(ds[j].TenNhanVien) > 0)
                    {
                        NhanVien tmp = ds[i];
                        ds[i] = ds[j];
                        ds[j] = tmp;
                    }
            Console.WriteLine("{0,-5} {1,-15} {2,-20} {3,-15} {4,-10}","STT", "Ma nhan vien", "Ho ten", "Ngay sinh", "He so luong");
            int stt = 1;
            for (int i = 0; i < ds.Count; i++)
            {
                Console.WriteLine("{0,-5} {1,-15} {2,-20} {3,-15} {4,-10}",stt,ds[i].MaNhanVien, ds[i].TenNhanVien,ds[i].NgaySinh.ToString("dd/MM/yyyy"),ds[i].HeSoLuong);
                stt++;
           
            }
        }
    }
}
