﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySInhVien
{
    public partial class FormChinh : Form
    {
        public FormChinh()
        {
            InitializeComponent();
        }

        private void btnNapDanhSach_Click(object sender, EventArgs e)
        {
            List<SinhVien> lst = new List<SinhVien>();
            string filename = "D:\\.NetFrame\\Baitap\\QuanLySInhVien\\sinhvien.txt";
            StreamReader sr = new StreamReader(filename);
            while (true)
            {
                string line = sr.ReadLine();
                if (line == null)
                    break;

                // Chuyển line => đối tượng SinhVien
                // SV001,Nguyễn Văn An,T101,Nam,15/5/2004,Sinh viên năm 2
                string[] info = line.Split(',');
                string maSinhVien = info[0];
                string hoTen = info[1];
                string maNganhDaoTao = info[2];
                bool gioiTinhNam = info[3] == "Nam";

                string stNgaySinh = info[4];
                DateTime ngaySinh = DateTime.ParseExact(stNgaySinh, "d/M/yyyy", null);

                string ghiChu = info[5];

                SinhVien sv = new SinhVien
                {
                    MaSinhVien = maSinhVien,
                    HoTen = hoTen,
                    MaNganhDaoTao = maNganhDaoTao,
                    GioiTinhNam = gioiTinhNam,
                    NgaySinh = ngaySinh,
                    GhiChu = ghiChu
                };

                lst.Add(sv);
            }
            sr.Close();

            //Hiển thị danh sách lên listbox
            lbxSinhVien.Items.Clear();
            for (int i = 0; i < lst.Count; i++)
            {
                lbxSinhVien.Items.Add(lst[i]);
            }

            //Hiển thị phần tử đang chọn hiện tại
            //kích hoạt sự kiện
            lbxSinhVien_SelectedIndexChanged(null, null);
            //Hiển thị thông tin thống kê
            lblThongKe.Text = string.Format("Danh sách có {0} sinh viên", lst.Count);
        }

        private void FormChinh_Load(object sender, EventArgs e)
        {
            btnNapDanhSach_Click(null, null);
        }

        private void lbxSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lbxSinhVien.SelectedItem == null)
            {
                //Người dùng không chọn phần tử nào
                txtMaSinhVien.Text = "";
                txtHoTen.Text = "";
                chkGioiTinhNam.Checked = false;
                txtMaNganhDaoTao.Text = "";
                txtNgaySinh.Text = "";
                txtGhiChu.Text = "";
            }
            else
            {
                //người dùng đang chọn sinh viên trên listbox
                SinhVien x = lbxSinhVien.SelectedItem as SinhVien;
                // Trình bày thông tin chi tiết lên GUI
                txtMaSinhVien.Text = x.MaSinhVien;
                txtHoTen.Text = x.HoTen;
                chkGioiTinhNam.Checked = x.GioiTinhNam;
                txtMaNganhDaoTao.Text = x.MaNganhDaoTao;
                txtNgaySinh.Text = x.NgaySinh.ToString("dd/MM/yyyy");
                txtGhiChu.Text = x.GhiChu;
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if(lbxSinhVien.SelectedItem == null)
            {
                return;
            }
            else
            {
                //xóa phần tử được chọn
                SinhVien x = lbxSinhVien.SelectedItem as SinhVien;
                lbxSinhVien.Items.Remove(x);
                //cập nhật thông tin thống kê
                lblThongKe.Text = string.Format("Danh sách có {0} sinh viên", lbxSinhVien.Items.Count);

                //Ghi danh sách xuống đĩa
                String filename = "D:\\.NetFrame\\Baitap\\QuanLySInhVien\\sinhvien.txt";
                String stNoiDung = "";
                for(int i = 0;i < lbxSinhVien.Items.Count; i++)
                {
                    SinhVien sv = lbxSinhVien.Items[i] as SinhVien;
                    String line = String.Format("{0},{1},{2},{3},{4},{5}", 
                        sv.MaSinhVien,
                        sv.HoTen,
                        sv.GioiTinhNam == true?"Nam":"Nữ",
                        sv.MaNganhDaoTao,
                        sv.NgaySinh.ToString("d/M/yyyy"),
                        sv.GhiChu
                     );
                    if (i == 0)
                        stNoiDung += line;
                    else
                        stNoiDung += "\r\n" + line;
                }
                System.IO.File.WriteAllText(filename, stNoiDung);
            }
        }
    }
}
