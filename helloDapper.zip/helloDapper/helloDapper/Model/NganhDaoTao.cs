﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helloDapper.Model
{
    public class NganhDaoTao
    {
        // MaNganhDaoTao (nvarchar(50) NOT NULL)
        public string MaNganhDaoTao { get; set; }

        // TenNganhDaoTao (nvarchar(100) NULL)
        public string TenNganhDaoTao { get; set; }
    }
}
