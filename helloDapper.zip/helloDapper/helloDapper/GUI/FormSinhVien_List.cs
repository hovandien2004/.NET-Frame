﻿using helloDapper.DAO;
using helloDapper.GUI;
using helloDapper.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace helloDapper
{
    public partial class FormSinhVien_List : Form
    {
        public FormSinhVien_List()
        {
            InitializeComponent();
        }

        private void btnNapDanhSach_Click(object sender, EventArgs e)
        {
            // Đọc danh sách sinh viên
            SinhVienDAO daoSV = new SinhVienDAO();
            List<SinhVien> lst = daoSV.DocDanhSach();

            // Hiển thị lên datagrid
            // 1. Trỏ bsSinhVien đến danh sách
            bsSinhVien.DataSource = lst;

            // 2. Trỏ grid đến bsSinhvien
            gridSinhVien.AutoGenerateColumns = false;
            gridSinhVien.DataSource = bsSinhVien;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (bsSinhVien.Current == null)
            {
                MessageBox.Show("Phải chọn sinh viên trước khi xóa");
                return;
            }

            // Xác định sinh viên đang chọn
            SinhVien sv = bsSinhVien.Current as SinhVien;

            // Xóa sinh viên đang chọn
            SinhVienDAO daoSV = new SinhVienDAO();
            daoSV.Xoa(sv.MaSinhVien);

            // Nạp lại danh sách
            btnNapDanhSach.PerformClick();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (bsSinhVien.Current == null)
            {
                MessageBox.Show("Phải chọn sinh viên trước khi sửa");
                return;
            }

            // Xác định sinh viên đang chọn
            SinhVien sv = bsSinhVien.Current as SinhVien;

            // Chỉnh sửa sinh viên đang chọn
            FormSinhVien_Edit frm = new FormSinhVien_Edit(sv);
            frm.ShowDialog();

            // Nạp lại danh sách
            if (frm.DialogResult == DialogResult.OK)
            {
                btnNapDanhSach.PerformClick();
            }
        }
    }
}
