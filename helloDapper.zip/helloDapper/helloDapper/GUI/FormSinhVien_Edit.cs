﻿using helloDapper.DAO;
using helloDapper.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace helloDapper.GUI
{
    public partial class FormSinhVien_Edit : Form
    {
        public FormSinhVien_Edit(SinhVien sv)
        {
            InitializeComponent();

            // Đọc danh sách ngành đào tạo
            NganhDaoTaoDAO daoNganh = new NganhDaoTaoDAO();
            List<NganhDaoTao> lstNganh = daoNganh.DocDanhSach();

            // Hiển thị lên cbxNganhdaoTao
            cbxNganhDaoTao.DisplayMember = "TenNganhDaoTao";
            cbxNganhDaoTao.DataSource = lstNganh;

            // Hiển thị chi tiết sinh viên lên màn hình
            txtMaSinhVien.Text = sv.MaSinhVien;
            txtHoTen.Text = sv.HoTen;
            chkGioiTinhNam.Checked = sv.GioiTinhNam.Value;

            if (sv.NgaySinh.HasValue)
            {
                dtpNgaySinh.Checked = true;
                dtpNgaySinh.Value = sv.NgaySinh.Value;
            }
            else
            {
                dtpNgaySinh.Checked = false;
            }

            // Chọn đúng vị trí của cbxNganhdaoTao theo mã ngành của sv
            for (int i = 0; i < cbxNganhDaoTao.Items.Count; i++)
            {
                NganhDaoTao nganh = cbxNganhDaoTao.Items[i] as NganhDaoTao;
                if (nganh.MaNganhDaoTao == sv.MaNganhDaoTao)
                {
                    cbxNganhDaoTao.SelectedIndex = i;
                    break;
                }
            }

            txtGhiChu.Text = sv.GhiChu;
        }

        private void btnDongY_Click(object sender, EventArgs e)
        {
            // Thu thập dữ liệu trên màn hình
            string maSinhVien = txtMaSinhVien.Text;
            string hoTen = txtHoTen.Text;
            bool gioiTinhNam = chkGioiTinhNam.Checked;

            DateTime? ngaySinh;
            if (dtpNgaySinh.Checked == false)
                ngaySinh = null;
            else
                ngaySinh = dtpNgaySinh.Value;

            string maNganhDaoTao;
            if (cbxNganhDaoTao.SelectedItem == null)
                maNganhDaoTao = null;
            else
            {
                NganhDaoTao nganh = cbxNganhDaoTao.SelectedItem as NganhDaoTao;
                maNganhDaoTao = nganh.MaNganhDaoTao;
            }

            string ghiChu = txtGhiChu.Text;

            // Thực hiện việc update lên CSDL
            SinhVienDAO daoSV = new SinhVienDAO();
            daoSV.CapNhat(maSinhVien, hoTen, gioiTinhNam, ngaySinh, maNganhDaoTao, ghiChu);

            // Đóng form
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnBoQua_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
