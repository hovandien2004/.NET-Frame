﻿using Dapper;
using helloDapper.Model;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helloDapper.DAO
{
    internal class SinhVienDAO
    {

        private DbConnection GetConnection()
        {
            DbConnection cnn = new SqlConnection();
            cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";
            cnn.Open();

            return cnn;
        }
        public List<SinhVien> DocDanhSach()
        {
            DbConnection cnn = GetConnection();

            string sql = @"
SELECT        MaSinhVien, NgaySinh, GhiChu, MaNganhDaoTao, GioiTinhNam, HoTen
FROM            SinhVien
ORDER BY HoTen
";

            List<SinhVien> lst = cnn.Query<SinhVien>(sql).ToList();

            return lst;
        }


        public void Xoa(string maSV)
        {
            DbConnection cnn = GetConnection();

            string sql = @"DELETE FROM SinhVien WHERE (MaSinhVien = @MaSinhVien)";

            var arrThamSo = new { MaSinhVien = maSV };

            int n = cnn.Execute(sql, arrThamSo);
        }

        public void CapNhat(string maSinhVien, string hoTen, bool gioiTinhNam, DateTime? ngaySinh, string maNganhDaoTao, string ghiChu)
        {
            DbConnection cnn = GetConnection();

            string sql = @"
UPDATE       SinhVien
SET          HoTen = @HoTen, 
			 GioiTinhNam = @GioiTinh, 
			 NgaySinh = @NgaySinh, 
			 MaNganhDaoTao = @MaNganhDaoTao, 
			 GhiChu = @GhiChu
WHERE        (MaSinhVien = @MaSinhVien)
";

            var arrThamSo = new
            {
                HoTen = hoTen,
                GioiTinh = gioiTinhNam, // tên thuộc tính = tên tham số trong sql
                NgaySinh = ngaySinh,
                MaNganhDaoTao = maNganhDaoTao,
                GhiChu = ghiChu,
                MaSinhVien = maSinhVien
            };

            int n = cnn.Execute(sql, arrThamSo);
        }
    }
}
