﻿using Dapper;
using helloDapper.Model;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helloDapper.DAO
{
    public class NganhDaoTaoDAO
    {
        public List<NganhDaoTao> DocDanhSach()
        {
            DbConnection cnn = new SqlConnection();
            cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";
            cnn.Open();

            string sql = @"
SELECT        MaNganhDaoTao, TenNganhDaoTao
FROM            NganhDaoTao
ORDER BY TenNganhDaoTao";

            List<NganhDaoTao> lst = cnn.Query<NganhDaoTao>(sql).ToList();

            return lst;
        }
    }
}
