﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Model
{
    public class NganhDaoTao
    {
        public string TenNganhDaoTao { get; set; }
        public string MaNganhDaoTao { get; set; }
        
        public string ThongTin
        {
            get
            {
                return string.Format("{0}({1})",
                TenNganhDaoTao,
                MaNganhDaoTao
                );
            }
        } 
    }
}
