﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien
{
    public class SinhVien
    {
        public string MaSinhVien { get; set; }

        public string HoTen { get; set; }

        public string MaNganhDaoTao { get; set; }

        public bool GioiTinhNam { get; set; }

        public DateTime NgaySinh { get; set; }

        public string GhiChu { get; set; }

        public override string ToString()
        {
            return this.HoTen + " - " + this.MaSinhVien;
        }
    }
}
