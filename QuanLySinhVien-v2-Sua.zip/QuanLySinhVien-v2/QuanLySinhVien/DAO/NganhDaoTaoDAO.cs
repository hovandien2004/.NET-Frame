﻿using Microsoft.SqlServer.Server;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.DAO
{
    public class NganhDaoTaoDAO
    {
        private string FILE_NAME = "D:\\22t1020067\\QuanLySinhVien-v2\\QuanLySinhVien\\DuLieuNganhDaoTao.txt";

        public List<NganhDaoTao> DocDanhSach()
        {
            List<NganhDaoTao> lst = new List<NganhDaoTao>();
            StreamReader sr = new StreamReader(FILE_NAME);
            while (true)
            {
                string line = sr.ReadLine();
                if (line == null)
                    break;

                string[] info = line.Split(',');
                string maNganh = info[0];
                string tenNganh = info[1];

                NganhDaoTao ndt = new NganhDaoTao
                {
                    MaNganhDaoTao = maNganh,
                    TenNganhDaoTao = tenNganh
                };

                lst.Add(ndt);
            }
            sr.Close();

            return lst;
        }
    }
}
