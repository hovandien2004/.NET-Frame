﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.DAO
{
    public class SinhVienDAO
    {
        private static string FILE_NAME = "D:\\22t1020067\\QuanLySinhVien-v2\\QuanLySinhVien\\DuLieuSinhVien.txt";

        public List<SinhVien> DocDanhSach()
        {
            #region List<SinhVien> lst = đọc danh sách từ file;
            List<SinhVien> lst = new List<SinhVien>();
            string filename = FILE_NAME;
            StreamReader sr = new StreamReader(filename);
            while (true)
            {
                string line = sr.ReadLine();
                if (line == null)
                    break;

                // Chuyển line => đối tượng SinhVien
                // SV001,Nguyễn Văn An,T101,Nam,15/5/2004,Sinh viên năm 2
                string[] info = line.Split(',');
                string maSinhVien = info[0];
                string maNganhDaoTao = info[1];
                string hoTen = info[2];
                bool gioiTinhNam = info[3] == "Nam";

                string stNgaySinh = info[4];
                DateTime ngaySinh = DateTime.ParseExact(stNgaySinh, "d/M/yyyy", null);

                string ghiChu = info[5];

                SinhVien sv = new SinhVien
                {
                    MaSinhVien = maSinhVien,
                    HoTen = hoTen,
                    MaNganhDaoTao = maNganhDaoTao,
                    GioiTinhNam = gioiTinhNam,
                    NgaySinh = ngaySinh,
                    GhiChu = ghiChu
                };

                lst.Add(sv);
            }
            sr.Close();
            #endregion

            return lst;
        }

        public void GhiDanhSach(List<SinhVien> lst)
        {
            #region lưu danh danh sách sinh viên trong lbxSinhVien xuống file
            string stNoiDung = "";
            for (int i = 0; i < lst.Count; i++)
            {
                SinhVien sv = lst[i] as SinhVien;
                // mã sinh viên, Mã ngành đào tạo, Họ tên, Giới tính, Ngày sinh, Ghi chú
                string line = string.Format("{0},{1},{2},{3},{4},{5}",
                    sv.MaSinhVien,
                    sv.MaNganhDaoTao,
                    sv.HoTen,
                    sv.GioiTinhNam ? "Nam" : "Nữ",
                    sv.NgaySinh.ToString("d/M/yyyy"),
                    sv.GhiChu
                    );
                if (i == 0)
                    stNoiDung += line;
                else
                    stNoiDung += "\r\n" + line;
            }
            System.IO.File.WriteAllText(FILE_NAME, stNoiDung);
            #endregion

        }

        public void BoSung(SinhVien sv)
        {
            string dong = string.Format("{0},{1},{2},{3},{4},{5}",
                sv.MaSinhVien,
                sv.MaNganhDaoTao,
                sv.HoTen,
                sv.GioiTinhNam ? "Nam" : "Nữ",
                sv.NgaySinh.ToString("d/M/yyyy"),
                sv.GhiChu);

            // Ghi bổ sung vào cuối file
            using (StreamWriter sw = new StreamWriter(FILE_NAME, true))
            {
                // sw.WriteLine(dong);
                sw.WriteLine(); // ghi ký tự xuống dòng
                sw.Write(dong); // ghi nội dung tương ứng sv
            }
        }

        internal void CapNhat(SinhVien sv)
        {
            //Đọc danh sách sinh viên từ file
            List<SinhVien> lst = DocDanhSach();
            //Thay sv vào vị trí thích hợp trong lst
            for (int i = 0; i < lst.Count; i++)
            {
                if (lst[i].MaSinhVien == sv.MaSinhVien)
                    lst[i] = sv;
            }
            //Ghi file xuống file
            GhiDanhSach(lst);
        }
    }
}
