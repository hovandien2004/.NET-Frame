﻿using QuanLySinhVien.DAO;
using QuanLySinhVien.GUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class FormChinh : Form
    {

        public FormChinh()
        {
            InitializeComponent();
        }

        private void btnNapDanhSach_Click(object sender, EventArgs e)
        {
            #region List<SinhVien> lst = đọc danh sách từ file;
            SinhVienDAO dao = new SinhVienDAO();
            List<SinhVien> lst = dao.DocDanhSach();
            #endregion

            #region Hiển thị danh sách sinh viên lst lên listbox
            lbxSinhVien.Items.Clear();
            for (int i = 0; i < lst.Count; i++)
                lbxSinhVien.Items.Add(lst[i]);
            #endregion

            #region Hiển thị thông tin thống kê
            lblThongKe.Text = string.Format("Danh sách có {0} sinh viên", lbxSinhVien.Items.Count);
            #endregion
        }

        private void FormChinh_Load(object sender, EventArgs e)
        {
            btnNapDanhSach_Click(null, null);
        }

        private void lbxSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxSinhVien.SelectedItem == null)
            {
                // Người dùng đang chưa chọn sinh viên nào -> xóa trắng thông tin chi tiết
                txtMaSinhVien.Text = "";
                txtHoTen.Text = "";
                chkGioiTinhNam.Checked = false;
                txtMaNganhDaoTao.Text = "";
                dtpNgaySinh.Value = DateTime.Now;
                txtGhiChu.Text = "";
            }
            else
            {
                // Người dùng đang chọn một sinh viên cụ thể
                #region Xác định sv = sinh viên đang chọn trên lbx
                SinhVien sv = lbxSinhVien.SelectedItem as SinhVien;
                #endregion

                #region Hiển thị thông tin chi tiết của sv
                txtMaSinhVien.Text = sv.MaSinhVien;
                txtHoTen.Text = sv.HoTen;
                chkGioiTinhNam.Checked = sv.GioiTinhNam;
                txtMaNganhDaoTao.Text = sv.MaNganhDaoTao;
                dtpNgaySinh.Value = sv.NgaySinh;
                txtGhiChu.Text = sv.GhiChu;
                #endregion

            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (lbxSinhVien.SelectedItem == null)
            {
                // Đang không chọn sinh viên nào -> Báo lỗi
                MessageBox.Show("Phải chọn sinh viên để xóa!", "Thông báo");
                return;
            }
            else
            {
                // đang chọn một sinh viên -> Xóa sinh viên này khỏi lbx
                #region xóa sinh viên đang chọn khỏi lbxSinhVien
                lbxSinhVien.Items.Remove(lbxSinhVien.SelectedItem);
                #endregion

                #region lưu danh danh sách sinh viên trong lbxSinhVien xuống file
                SinhVienDAO dao = new SinhVienDAO();

                #region List<SinhVien> lst = danh sách sinh viên tạo từ lbx
                List<SinhVien> lst = new List<SinhVien>();
                for (int i = 0; i < lbxSinhVien.Items.Count; i++)
                    lst.Add(lbxSinhVien.Items[i] as SinhVien); 
                #endregion

                dao.GhiDanhSach(lst);
                #endregion

                #region hiển thị lại danh sách sinh viên
                btnNapDanhSach_Click(null, null);
                #endregion
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            FormSinhVien_Them frm = new FormSinhVien_Them();
            //frm.StartPosition = FormStartPosition.CenterScreen;
            frm.StartPosition = FormStartPosition.CenterParent;

            //frm.Show();
            frm.ShowDialog();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            #region Xác định sinh viên đang chọn
            SinhVien sv = null;
            if (lbxSinhVien.SelectedItem != null)
            {
                sv = lbxSinhVien.SelectedItem as SinhVien;
            }
            if (sv == null) 
            {
                MessageBox.Show("Phải chọn sinh viên để sửa");
            }

            #endregion
            #region hiển thị form sửa với sinh viên đang chọn
            FormSinhVien_Sua frm = new FormSinhVien_Sua(sv);
            frm.ShowDialog();
            #endregion
        }
    }
}
