﻿using QuanLySinhVien.DAO;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.GUI
{
    public partial class FormSinhVien_Them : Form
    {
        public FormSinhVien_Them()
        {
            InitializeComponent();
            #region list<NganhDaoTao> lstNDT = đọc từ file
            NganhDaoTaoDAO daoNDT = new NganhDaoTaoDAO();
            List<NganhDaoTao> lstNDT = daoNDT.DocDanhSach();
            #endregion

            #region hiển thị lstNDT lên cbxNganhDaoTao
            cbxNganhDaoTao.DisplayMember = "ThongTin";
            cbxNganhDaoTao.Items.Clear();
            for (int i = 0; i < lstNDT.Count; i++)
            {
                cbxNganhDaoTao.Items.Add(lstNDT[i]);
            }    
            #endregion

        }

        private void btnBoQua_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDongY_Click(object sender, EventArgs e)
        {
            #region Thu thập dữ liệu trên GUI
            string maSinhVien = txtMaSinhVien.Text;
            string hoTen = txtHoTen.Text;
            bool gioiTinhNam = chkGioiTinhNam.Checked;

            string maNganhDaoTao;
            if (cbxNganhDaoTao.SelectedItem == null)
            {
                maNganhDaoTao = null;
            }
            else
            {
                NganhDaoTao ndtDangChon = cbxNganhDaoTao.SelectedItem as NganhDaoTao;
                maNganhDaoTao = ndtDangChon.MaNganhDaoTao;
            }
            //string maNganhDaoTao = txtMaNganhDaoTao.Text;
            DateTime ngaySinh = dtpNgaySinh.Value;
            string ghiChu = txtGhiChu.Text;
            #endregion

            #region Tạo đối tượng SinhVien từ dữ liệu
            SinhVien sv = new SinhVien()
            {
                MaSinhVien = maSinhVien,
                HoTen = hoTen,
                GioiTinhNam = gioiTinhNam,
                MaNganhDaoTao = maNganhDaoTao,
                NgaySinh = ngaySinh,
                GhiChu = ghiChu
            };
            #endregion

            #region Ghi đối tượng lên file
            SinhVienDAO dao = new SinhVienDAO();
            dao.BoSung(sv);
            #endregion

            #region Đóng form
            this.Close();
            #endregion
        }
    }
}
