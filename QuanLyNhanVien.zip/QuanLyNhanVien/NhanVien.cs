﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyNhanVien
{
    internal class NhanVien
    {
        public string MaNhanVien { get; set; }
        public string TenNhanVien { get; set; }
        public bool GioiTinh {  get; set; }
        public DateTime NgaySinh { get; set; }
        public double HeSoLuong { get; set; }

        public NhanVien(string maNhanVien, string tenNhanVien, bool gioiTinh, DateTime ngaySinh, double heSoLuong)
        {
            MaNhanVien = maNhanVien;
            TenNhanVien = tenNhanVien;
            GioiTinh = gioiTinh;
            NgaySinh = ngaySinh;
            HeSoLuong = heSoLuong;
        }
    }
}
