﻿namespace helloDB01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gridKetQua = new System.Windows.Forms.DataGridView();
            this.btnSelectNhieuHangNhieuCot = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gridKetQuaNganhDaoTao = new System.Windows.Forms.DataGridView();
            this.btnAllNganh = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnSelect1GiaTri = new System.Windows.Forms.Button();
            this.S = new System.Windows.Forms.TabPage();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaSinhVien = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkGioiTinhNam = new System.Windows.Forms.CheckBox();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnInSert = new System.Windows.Forms.Button();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.cbxNganhDaoTao = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridKetQua)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridKetQuaNganhDaoTao)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.S.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.S);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(787, 437);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.gridKetQua);
            this.tabPage1.Controls.Add(this.btnSelectNhieuHangNhieuCot);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(779, 411);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Nhiều hàng nhiều cột";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // gridKetQua
            // 
            this.gridKetQua.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridKetQua.Location = new System.Drawing.Point(0, 47);
            this.gridKetQua.Name = "gridKetQua";
            this.gridKetQua.Size = new System.Drawing.Size(776, 361);
            this.gridKetQua.TabIndex = 1;
            // 
            // btnSelectNhieuHangNhieuCot
            // 
            this.btnSelectNhieuHangNhieuCot.Location = new System.Drawing.Point(7, 18);
            this.btnSelectNhieuHangNhieuCot.Name = "btnSelectNhieuHangNhieuCot";
            this.btnSelectNhieuHangNhieuCot.Size = new System.Drawing.Size(75, 23);
            this.btnSelectNhieuHangNhieuCot.TabIndex = 0;
            this.btnSelectNhieuHangNhieuCot.Text = "Truy vấn";
            this.btnSelectNhieuHangNhieuCot.UseVisualStyleBackColor = true;
            this.btnSelectNhieuHangNhieuCot.Click += new System.EventHandler(this.btnSelectNhieuHangNhieuCot_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.gridKetQuaNganhDaoTao);
            this.tabPage2.Controls.Add(this.btnAllNganh);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(779, 411);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "All Ngành";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // gridKetQuaNganhDaoTao
            // 
            this.gridKetQuaNganhDaoTao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridKetQuaNganhDaoTao.Location = new System.Drawing.Point(0, 44);
            this.gridKetQuaNganhDaoTao.Name = "gridKetQuaNganhDaoTao";
            this.gridKetQuaNganhDaoTao.Size = new System.Drawing.Size(773, 364);
            this.gridKetQuaNganhDaoTao.TabIndex = 1;
            // 
            // btnAllNganh
            // 
            this.btnAllNganh.Location = new System.Drawing.Point(6, 6);
            this.btnAllNganh.Name = "btnAllNganh";
            this.btnAllNganh.Size = new System.Drawing.Size(75, 23);
            this.btnAllNganh.TabIndex = 0;
            this.btnAllNganh.Text = "Truy Vấn";
            this.btnAllNganh.UseVisualStyleBackColor = true;
            this.btnAllNganh.Click += new System.EventHandler(this.btnAllNganh_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Controls.Add(this.btnSelect1GiaTri);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(779, 411);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "một hàng một cột";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 35);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(770, 373);
            this.dataGridView1.TabIndex = 1;
            // 
            // btnSelect1GiaTri
            // 
            this.btnSelect1GiaTri.Location = new System.Drawing.Point(6, 6);
            this.btnSelect1GiaTri.Name = "btnSelect1GiaTri";
            this.btnSelect1GiaTri.Size = new System.Drawing.Size(75, 23);
            this.btnSelect1GiaTri.TabIndex = 0;
            this.btnSelect1GiaTri.Text = "Thực thi truy vấn";
            this.btnSelect1GiaTri.UseVisualStyleBackColor = true;
            this.btnSelect1GiaTri.Click += new System.EventHandler(this.btnSelect1GiaTri_Click);
            // 
            // S
            // 
            this.S.Controls.Add(this.cbxNganhDaoTao);
            this.S.Controls.Add(this.btnUpdate);
            this.S.Controls.Add(this.dtpNgaySinh);
            this.S.Controls.Add(this.btnInSert);
            this.S.Controls.Add(this.btnXoa);
            this.S.Controls.Add(this.chkGioiTinhNam);
            this.S.Controls.Add(this.txtGhiChu);
            this.S.Controls.Add(this.label5);
            this.S.Controls.Add(this.label4);
            this.S.Controls.Add(this.txtHoTen);
            this.S.Controls.Add(this.label3);
            this.S.Controls.Add(this.label2);
            this.S.Controls.Add(this.txtMaSinhVien);
            this.S.Controls.Add(this.label1);
            this.S.Location = new System.Drawing.Point(4, 22);
            this.S.Name = "S";
            this.S.Padding = new System.Windows.Forms.Padding(3);
            this.S.Size = new System.Drawing.Size(779, 411);
            this.S.TabIndex = 3;
            this.S.Text = "D-I-U";
            this.S.UseVisualStyleBackColor = true;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(137, 189);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(178, 20);
            this.txtGhiChu.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Ghi chú";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Ngành đào tạo";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(137, 65);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(178, 20);
            this.txtHoTen.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Họ tên:";
            // 
            // txtMaSinhVien
            // 
            this.txtMaSinhVien.Location = new System.Drawing.Point(137, 30);
            this.txtMaSinhVien.Name = "txtMaSinhVien";
            this.txtMaSinhVien.Size = new System.Drawing.Size(178, 20);
            this.txtMaSinhVien.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Sinh Viên";
            // 
            // chkGioiTinhNam
            // 
            this.chkGioiTinhNam.AutoSize = true;
            this.chkGioiTinhNam.Location = new System.Drawing.Point(137, 92);
            this.chkGioiTinhNam.Name = "chkGioiTinhNam";
            this.chkGioiTinhNam.Size = new System.Drawing.Size(95, 17);
            this.chkGioiTinhNam.TabIndex = 2;
            this.chkGioiTinhNam.Text = "Giới Tính Nam";
            this.chkGioiTinhNam.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(396, 28);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 23);
            this.btnXoa.TabIndex = 3;
            this.btnXoa.Text = "Delete";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnInSert
            // 
            this.btnInSert.Location = new System.Drawing.Point(396, 86);
            this.btnInSert.Name = "btnInSert";
            this.btnInSert.Size = new System.Drawing.Size(75, 23);
            this.btnInSert.TabIndex = 4;
            this.btnInSert.Text = "Insert";
            this.btnInSert.UseVisualStyleBackColor = true;
            this.btnInSert.Click += new System.EventHandler(this.btnInSert_Click);
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Location = new System.Drawing.Point(137, 122);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(200, 20);
            this.dtpNgaySinh.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Giới tính:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(396, 144);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 6;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // cbxNganhDaoTao
            // 
            this.cbxNganhDaoTao.FormattingEnabled = true;
            this.cbxNganhDaoTao.Location = new System.Drawing.Point(137, 154);
            this.cbxNganhDaoTao.Name = "cbxNganhDaoTao";
            this.cbxNganhDaoTao.Size = new System.Drawing.Size(200, 21);
            this.cbxNganhDaoTao.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridKetQua)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridKetQuaNganhDaoTao)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.S.ResumeLayout(false);
            this.S.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnSelectNhieuHangNhieuCot;
        private System.Windows.Forms.DataGridView gridKetQua;
        private System.Windows.Forms.DataGridView gridKetQuaNganhDaoTao;
        private System.Windows.Forms.Button btnAllNganh;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnSelect1GiaTri;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage S;
        private System.Windows.Forms.TextBox txtMaSinhVien;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnInSert;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.CheckBox chkGioiTinhNam;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ComboBox cbxNganhDaoTao;
    }
}

