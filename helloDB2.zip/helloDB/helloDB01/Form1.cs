﻿using HelloDB01.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace helloDB01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadNganhDaoTao();
        }
        public static DbConnection GetConnection()
        {
            
                DbConnection cnn = new SqlConnection();
                //cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;User Id=sa;Password=123;";
                cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

                cnn.Open();
                return cnn;
            
        
        }
        private void btnSelectNhieuHangNhieuCot_Click(object sender, EventArgs e)
        {
            #region 1. Tạo kết nối
            DbConnection cnn = GetConnection();
            #endregion

            #region 2. Tạo command
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
  SELECT MaSinhVien, HoTen, GioiTinhNam, NgaySinh, MaNganhDaoTao, GhiChu
    FROM SinhVien
ORDER BY MaNganhDaoTao
";
            #endregion

            #region 3. Thực thi command - trả về nhiều hàng, nhiều cột <-> DbDataReader
            DbDataReader dr = cmd.ExecuteReader();
            #endregion

            #region 4. Khai thác dữ liệu
            List<SinhVien> lst = new List<SinhVien>();
            while (dr.Read())
            {
                string maSinhVien = dr.GetString(0);
                string hoTen = dr.GetString(1);
                bool gioiTinhNam = dr.GetBoolean(2);

                DateTime? ngaySinh = null;

                // Cần phải bảo đảm dữ liệu ở cột có chỉ số 3 != NULL thì mới GetValue được
                if (dr.IsDBNull(3) == false)
                    ngaySinh = dr.GetDateTime(3);

                string maNganh = dr.GetString(4);
                string ghiChu = dr.GetString(5);

                SinhVien sv = new SinhVien()
                {
                    MaSinhVien = maSinhVien,
                    HoTen = hoTen,
                    GioiTinhNam = gioiTinhNam,
                    NgaySinh = ngaySinh,
                    MaNganhDaoTao = maNganh,
                    GhiChu = ghiChu
                };
                lst.Add(sv);
            }
            #endregion

            #region 5. Giải phóng tài nguyên
            dr.Close();
            cnn.Close();
            #endregion


            // Hiển thị danh sách vừa đọc được lên gridKetQua
            gridKetQua.AutoGenerateColumns = true;
            gridKetQua.DataSource = lst;
        }

        private void btnAllNganh_Click(object sender, EventArgs e)
        {
            #region 1. Tạo kết nối
            DbConnection cnn = new SqlConnection();
            //cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;User Id=sa;Password=123;";
            cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

            cnn.Open();
            #endregion

            #region 2. Tạo command
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
                                select MaNganhDaoTao, TenNganhDaoTao
                        from NganhDaoTao
                    ";
            #endregion

            #region 3. Thực thi command - trả về nhiều hàng, nhiều cột <-> DbDataReader
            DbDataReader dr = cmd.ExecuteReader();
            #endregion

            #region 4. Khai thác dữ liệu
            List<NganhDaoTao> lst = new List<NganhDaoTao>();
            while (dr.Read())
            {
                string maNganh = dr.GetString(0);
                string tenNganh = dr.GetString(1);
                NganhDaoTao nganhDT = new NganhDaoTao()
                {
                    MaNganhDaoTao = maNganh,
                    TenNganhDaoTao = tenNganh
                };
                lst.Add(nganhDT);
            }
            #endregion

            #region 5. Giải phóng tài nguyên
            dr.Close();
            cnn.Close();
            #endregion


            // Hiển thị danh sách vừa đọc được lên gridKetQua
            gridKetQuaNganhDaoTao.AutoGenerateColumns = true;
            gridKetQuaNganhDaoTao.DataSource = lst;
        }

        private void btnSelect1GiaTri_Click(object sender, EventArgs e)
        {
            // 1. Tạo cnn
            DbConnection cnn = GetConnection();
            
            // 2. Tạo cmd
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
SELECT Min(NgaySinh)
FROM SinhVien
WHERE GioiTinhNam = 1
";

            // 3. Thực thi cmd trả về 1 giá trị
            object ketQua = cmd.ExecuteScalar();

            // 4. Khai thác kết quả truy vấn
            DateTime? ngaySinh;
            if (ketQua == null || ketQua == DBNull.Value)
                ngaySinh = null;
            else
                ngaySinh = (DateTime?)ketQua;

            // 5. Giải phóng tài nguyên
            cnn.Close();


            MessageBox.Show("Kết quả truy vấn " + ngaySinh);
        }
        void addParam(DbCommand cmd, String paramName, DbType paramType, object value)
        {
            DbParameter p = cmd.CreateParameter();
            p.ParameterName = paramName;
            p.DbType = paramType;
            p.Value = value;

            cmd.Parameters.Add(p);
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            // 1. Tạo cnn
            DbConnection cnn = GetConnection();

            // 2. Tạo cmd
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"DELETE FROM SinhVien WHERE MaSinhVien = @p1";

            //DbParameter p = cmd.CreateParameter();
            //p.ParameterName = "@p1";
            //p.DbType = DbType.String;
            //p.Value = txtMaSinhVien.Text;

            //cmd.Parameters.Add(p);
            addParam(cmd, "@p1", DbType.String, txtMaSinhVien.Text);

            // 3. Thực thi truy vấn
            int n = cmd.ExecuteNonQuery();

            // 4. Khai thác kết quả truy vấn
            MessageBox.Show("Số dòng bị ảnh hưởng là " + n);

            // 5. Giải phóng tài nguyên
            cnn.Close();
        }

        private void btnInSert_Click(object sender, EventArgs e)
        {
            // 1. Tạo cnn
            DbConnection cnn = GetConnection();

            // 2. Tạo cmd
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SinhVien
            (MaSinhVien, HoTen, GioiTinhNam, NgaySinh, MaNganhDaoTao, GhiChu)
VALUES      (@pMaSinhVien, @pHoTen, @pGioiTinhNam,@pNgaySinh,@pMaNganh,@pGhiChu)
";
            addParam(cmd, "@pMaSinhVien", DbType.String, txtMaSinhVien.Text);
            addParam(cmd, "@pHoTen", DbType.String, txtHoTen.Text);
            addParam(cmd, "@pGioiTinhNam", DbType.Boolean, chkGioiTinhNam.Checked);
            addParam(cmd, "@pNgaySinh", DbType.Date, dtpNgaySinh.Value);
            //addParam(cmd, "@pMaNganh", DbType.String, cbxNganhDaoTao.Text);
            // Lấy mã ngành đào tạo từ comboBoxNganhDaoTao.SelectedValue (phải ép kiểu string)
            //string maNganh = cbxNganhDaoTao.SelectedValue?.ToString() ?? "";
            string maNganh = cbxNganhDaoTao.SelectedValue?.ToString() ?? "";
            addParam(cmd, "@pMaNganh", DbType.String, maNganh);


            addParam(cmd, "@pGhiChu", DbType.String, txtGhiChu.Text);

            // 3. Thực thi cmd
            int n = cmd.ExecuteNonQuery();

            // 4. Khai thác kq
            if (n == 1)
                MessageBox.Show("Đã insert thành công");
            else
                MessageBox.Show("Lỗi trong quá trình insert");

            // 5. Giải phóng tài nguyên
            cnn.Close();
        }




        private void LoadNganhDaoTao()
        {
            DbConnection cnn = GetConnection();

            try
            {
                DbCommand cmd = cnn.CreateCommand();
                cmd.CommandText = "SELECT MaNganhDaoTao, TenNganhDaoTao FROM NganhDaoTao";

                using (DbDataReader reader = cmd.ExecuteReader())
                {
                    DataTable dt = new DataTable();
                    dt.Columns.Add("MaNganhDaoTao", typeof(string));
                    dt.Columns.Add("TenNganhDaoTao", typeof(string));
                    dt.Columns.Add("TenMa", typeof(string)); // cột hiển thị

                    while (reader.Read())
                    {
                        string ma = reader["MaNganhDaoTao"].ToString();
                        string ten = reader["TenNganhDaoTao"].ToString();
                        dt.Rows.Add(ma, ten, $"{ten} - {ma}");
                    }

                    cbxNganhDaoTao.DisplayMember = "TenMa";      // Hiển thị cả tên và mã
                    cbxNganhDaoTao.ValueMember = "MaNganhDaoTao"; // Giá trị thực
                    cbxNganhDaoTao.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi load ngành đào tạo: " + ex.Message);
            }
            finally
            {
                cnn.Close();
            }
        }




    }
}

