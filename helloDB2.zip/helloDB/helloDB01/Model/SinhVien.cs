﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloDB01.Model
{
    public class SinhVien
    {
        public string MaSinhVien { get; set; }

        public string HoTen { get; set; }

        public bool GioiTinhNam { get; set; }

        // Hoặc là Null, hoặc là DateTime
        public DateTime? NgaySinh { get; set; }

        public string MaNganhDaoTao { get; set; }

        public string GhiChu { get; set; }
    }
}