﻿using HelloDB2.DAO;
using HelloDB2.GUI;
using HelloDB2.Model;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace HelloDB2
{
    public partial class FormSinhVien_List : Form
    {
        private SinhVienDAO svDAO = new SinhVienDAO(); // DAO để thao tác dữ liệu

        public FormSinhVien_List()
        {
            InitializeComponent();
        }

        private void FormSinhVien_List_Load(object sender, EventArgs e)
        {
            NapDanhSachSinhVien(); // Tải danh sách khi mở form
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            FormSinhVien_Add frm = new FormSinhVien_Add();
            frm.ShowDialog();

            if (frm.DialogResult == DialogResult.OK)
            {
                NapDanhSachSinhVien(); // nạp lại danh sách sau khi thêm
            }
        }

        private void btnNapDanhSach_Click(object sender, EventArgs e)
        {
            NapDanhSachSinhVien(); // Nạp lại danh sách
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (gridSinhVien.CurrentRow != null)
            {
                string maSinhVien = gridSinhVien.CurrentRow.Cells["MaSinhVien"].Value.ToString();

                DialogResult rs = MessageBox.Show($"Bạn có chắc muốn xóa sinh viên {maSinhVien} không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (rs == DialogResult.Yes)
                {
                    svDAO.XoaSinhVien(maSinhVien);
                    NapDanhSachSinhVien(); // nạp lại danh sách sau khi xóa
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn sinh viên để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Hàm nạp danh sách sinh viên vào DataGridView
        private void NapDanhSachSinhVien()
        {
            List<SinhVien> lst = svDAO.DocDanhSach();
            gridSinhVien.DataSource = null; // reset
            gridSinhVien.DataSource = lst;

            // Tùy chọn hiển thị cột
            gridSinhVien.Columns["MaSinhVien"].HeaderText = "Mã sinh viên";
            gridSinhVien.Columns["HoTen"].HeaderText = "Họ tên";
            gridSinhVien.Columns["GioiTinhNam"].HeaderText = "Giới tính Nam";
            gridSinhVien.Columns["NgaySinh"].HeaderText = "Ngày sinh";
      
            gridSinhVien.Columns["MaNganhDaoTao"].HeaderText = "Mã ngành đào tạo";
            gridSinhVien.Columns["GhiChu"].HeaderText = "Ghi chú";
        }
    }
}
