﻿using HelloDB2.DAO;
using HelloDB2.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloDB2.GUI
{
    public partial class FormSinhVien_Add : Form
    {
        private NganhDaoTaoDAO nganhDAO = new NganhDaoTaoDAO();
        private SinhVienDAO svDAO = new SinhVienDAO();
        public FormSinhVien_Add()
        {
            InitializeComponent();
            NapDanhSachNganhDaoTao();
            // Đọc danh sách ngành đào tạo -> NganhDaoTaoDAO

            // Hiển thị lên cbxNganhDaoTao
        }

        private void btnBoQua_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void NapDanhSachNganhDaoTao()
        {

            List<NganhDaoTao> lstNganh = nganhDAO.DocDanhSach();
            cbxNganhDaoTao.DataSource = lstNganh;
            cbxNganhDaoTao.DisplayMember = "TenNganhDaoTao"; // Hiển thị tên ngành
            cbxNganhDaoTao.ValueMember = "MaNganhDaoTao";    // Giá trị thực tế là mã ngành
            cbxNganhDaoTao.SelectedIndex = -1; // Không chọn mặc định
        }
        private void btnDongY_Click(object sender, EventArgs e)
        {
            // 1. Thu thập dữ liệu trên form
            string maSinhVien = txtMaSinhVien.Text;
            string hoTen = txtHoTen.Text;
            bool gioiTinhNam = chkGioiTinhNam.Checked;

            //DateTime? ngaySinh;
            //if (dtpNgaySinh.Checked == false)
            //    ngaySinh = null;
            //else
            //   ngaySinh = dtpNgaySinh.Value;
            DateTime? ngaySinh = dtpNgaySinh.Checked ? (DateTime?)dtpNgaySinh.Value : null;

            string maNganhDaoTao;
            if (cbxNganhDaoTao.SelectedItem == null)
                maNganhDaoTao = null;
            else
                maNganhDaoTao = (cbxNganhDaoTao.SelectedItem as NganhDaoTao).MaNganhDaoTao;

            string ghiChu = txtGhiChu.Text;

            // 2. Tiến hành thêm mới sinh viên vào csdl -> SinhVienDAO
            svDAO.BoSungSinhVien(maSinhVien, hoTen, gioiTinhNam, ngaySinh, maNganhDaoTao, ghiChu);

            MessageBox.Show("Đã lưu sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // 3. Đóng form này
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

    
    }
}
