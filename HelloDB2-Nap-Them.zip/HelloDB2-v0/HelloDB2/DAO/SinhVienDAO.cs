﻿using HelloDB2.Model;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;

namespace HelloDB2.DAO
{
    // làm nhiệm vụ đọc/ghi dữ liệu SinhVien
    public class SinhVienDAO
    {
        private string connectionString = "Server=localhost;Database=SinhvienDB;Trusted_Connection=True;";

        // Đọc danh sách sinh viên
        public List<SinhVien> DocDanhSach()
        {
            // 1. Tạo kết nối
            DbConnection cnn = new SqlConnection();
            cnn.ConnectionString = connectionString;
            cnn.Open();

            // 2. Tạo command
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
SELECT MaSinhVien, HoTen, GioiTinhNam, NgaySinh, MaNganhDaoTao, GhiChu
FROM SinhVien
";

            // 3. Thực thi
            DbDataReader dr = cmd.ExecuteReader();

            // 4. Khai thác dữ liệu
            List<SinhVien> lst = new List<SinhVien>();
            while (dr.Read())
            {
                SinhVien sv = new SinhVien()
                {
                    MaSinhVien = dr.GetString(0),
                    HoTen = dr.IsDBNull(1) ? null : dr.GetString(1),
                    GioiTinhNam = dr.IsDBNull(2) ? (bool?)null : dr.GetBoolean(2),
                    NgaySinh = dr.IsDBNull(3) ? (DateTime?)null : dr.GetDateTime(3),
                    MaNganhDaoTao = dr.IsDBNull(4) ? null : dr.GetString(4),
                    GhiChu = dr.IsDBNull(5) ? null : dr.GetString(5)
                };

                lst.Add(sv);
            }

            // 5. Giải phóng tài nguyên
            dr.Close();
            cnn.Close();

            return lst;
        }

        // Xóa sinh viên theo mã
        public void XoaSinhVien(string maSinhVien)
        {
            DbConnection cnn = new SqlConnection();
            cnn.ConnectionString = connectionString;
            cnn.Open();

            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = "DELETE FROM SinhVien WHERE MaSinhVien = @MaSinhVien";

            var param = cmd.CreateParameter();
            param.ParameterName = "@MaSinhVien";
            param.Value = maSinhVien;
            cmd.Parameters.Add(param);

            cmd.ExecuteNonQuery();
            cnn.Close();
        }

        // Thêm hoặc cập nhật sinh viên
        public void BoSungSinhVien(string maSinhVien, string hoTen, bool? gioiTinhNam, DateTime? ngaySinh, string maNganhDaoTao, string ghiChu)
        {
            DbConnection cnn = new SqlConnection();
            cnn.ConnectionString = connectionString;
            cnn.Open();

            // 1. Kiểm tra sinh viên tồn tại chưa
            DbCommand checkCmd = cnn.CreateCommand();
            checkCmd.CommandText = "SELECT COUNT(*) FROM SinhVien WHERE MaSinhVien = @MaSinhVien";

            var paramCheck = checkCmd.CreateParameter();
            paramCheck.ParameterName = "@MaSinhVien";
            paramCheck.Value = maSinhVien;
            checkCmd.Parameters.Add(paramCheck);

            int count = Convert.ToInt32(checkCmd.ExecuteScalar());

            if (count > 0)
            {
                // Cập nhật
                DbCommand updateCmd = cnn.CreateCommand();
                updateCmd.CommandText = @"
UPDATE SinhVien
SET HoTen = @HoTen,
    GioiTinhNam = @GioiTinhNam,
    NgaySinh = @NgaySinh,
    MaNganhDaoTao = @MaNganhDaoTao,
    GhiChu = @GhiChu
WHERE MaSinhVien = @MaSinhVien";

                var p1 = updateCmd.CreateParameter();
                p1.ParameterName = "@MaSinhVien";
                p1.Value = maSinhVien;
                updateCmd.Parameters.Add(p1);

                var p2 = updateCmd.CreateParameter();
                p2.ParameterName = "@HoTen";
                p2.Value = (object)hoTen ?? DBNull.Value;
                updateCmd.Parameters.Add(p2);

                var p3 = updateCmd.CreateParameter();
                p3.ParameterName = "@GioiTinhNam";
                p3.Value = (object)gioiTinhNam ?? DBNull.Value;
                updateCmd.Parameters.Add(p3);

                var p4 = updateCmd.CreateParameter();
                p4.ParameterName = "@NgaySinh";
                p4.Value = (object)ngaySinh ?? DBNull.Value;
                updateCmd.Parameters.Add(p4);

                var p5 = updateCmd.CreateParameter();
                p5.ParameterName = "@MaNganhDaoTao";
                p5.Value = (object)maNganhDaoTao ?? DBNull.Value;
                updateCmd.Parameters.Add(p5);

                var p6 = updateCmd.CreateParameter();
                p6.ParameterName = "@GhiChu";
                p6.Value = (object)ghiChu ?? DBNull.Value;
                updateCmd.Parameters.Add(p6);

                updateCmd.ExecuteNonQuery();
            }
            else
            {
                // Thêm mới
                DbCommand insertCmd = cnn.CreateCommand();
                insertCmd.CommandText = @"
INSERT INTO SinhVien (MaSinhVien, HoTen, GioiTinhNam, NgaySinh, MaNganhDaoTao, GhiChu)
VALUES (@MaSinhVien, @HoTen, @GioiTinhNam, @NgaySinh, @MaNganhDaoTao, @GhiChu)";

                var p1 = insertCmd.CreateParameter();
                p1.ParameterName = "@MaSinhVien";
                p1.Value = maSinhVien;
                insertCmd.Parameters.Add(p1);

                var p2 = insertCmd.CreateParameter();
                p2.ParameterName = "@HoTen";
                p2.Value = (object)hoTen ?? DBNull.Value;
                insertCmd.Parameters.Add(p2);

                var p3 = insertCmd.CreateParameter();
                p3.ParameterName = "@GioiTinhNam";
                p3.Value = (object)gioiTinhNam ?? DBNull.Value;
                insertCmd.Parameters.Add(p3);

                var p4 = insertCmd.CreateParameter();
                p4.ParameterName = "@NgaySinh";
                p4.Value = (object)ngaySinh ?? DBNull.Value;
                insertCmd.Parameters.Add(p4);

                var p5 = insertCmd.CreateParameter();
                p5.ParameterName = "@MaNganhDaoTao";
                p5.Value = (object)maNganhDaoTao ?? DBNull.Value;
                insertCmd.Parameters.Add(p5);

                var p6 = insertCmd.CreateParameter();
                p6.ParameterName = "@GhiChu";
                p6.Value = (object)ghiChu ?? DBNull.Value;
                insertCmd.Parameters.Add(p6);

                insertCmd.ExecuteNonQuery();
            }

            cnn.Close();
        }
    }
}
