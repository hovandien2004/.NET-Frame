﻿using HelloDB2.Model;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloDB2.DAO
{
    // làm nhiệm vụ đọc/ghi dữ liệu NganhDaoTao
    public class NganhDaoTaoDAO
    {
        public List<NganhDaoTao> DocDanhSach()
        {
            // 1. Tạo cnn
            DbConnection cnn = new SqlConnection();
            cnn.ConnectionString = "Server=localhost;Database=SinhvienDB;Trusted_Connection=True;";
            cnn.Open();

            // 2. Tạo cmd
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
SELECT        MaNganhDaoTao, TenNganhDaoTao
FROM            NganhDaoTao
";

            // 3. Thực thi cmd -> DbDataReader
            DbDataReader dr = cmd.ExecuteReader();

            // 4. Khai thác dữ liệu
            List<NganhDaoTao> lst = new List<NganhDaoTao>();
            while (dr.Read())
            {
                string maNganh = dr.GetString(0);
                string tenNganh = dr.GetString(1);

                NganhDaoTao nganh = new NganhDaoTao()
                {
                    MaNganhDaoTao = maNganh,
                    TenNganhDaoTao = tenNganh
                };

                lst.Add(nganh);
            }

            // 5. Giải phóng tài nguyên
            dr.Close();
            cnn.Close();

            return lst;
        }
    }
}
