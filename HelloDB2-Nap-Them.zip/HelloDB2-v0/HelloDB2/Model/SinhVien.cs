﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloDB2.Model
{
    public class SinhVien
    {
        // MaSinhVien (nvarchar(50) NOT NULL)
        public string MaSinhVien { get; set; }

        // HoTen (nvarchar(200) NULL)
        public string HoTen { get; set; }

        // GioiTinhNam (bit NULL)
        public bool? GioiTinhNam { get; set; }

        // NgaySinh (smalldatetime NULL)
        public DateTime? NgaySinh { get; set; }

        // MaNganhDaoTao (nvarchar(50) NULL)
        // Đây là Khóa ngoại, nhưng không cần thuộc tính điều hướng trong POCO
        public string MaNganhDaoTao { get; set; }

        // GhiChu (nvarchar(max) NULL)
        public string GhiChu { get; set; }

  
    }
}
