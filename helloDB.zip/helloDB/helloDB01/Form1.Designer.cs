﻿namespace helloDB01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnSelectNhieuHangNhieuCot = new System.Windows.Forms.Button();
            this.gridKetQua = new System.Windows.Forms.DataGridView();
            this.btnAllNganh = new System.Windows.Forms.Button();
            this.gridKetQuaNganhDaoTao = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridKetQua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridKetQuaNganhDaoTao)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(787, 437);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.gridKetQua);
            this.tabPage1.Controls.Add(this.btnSelectNhieuHangNhieuCot);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(779, 411);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Nhiều hàng nhiều cột";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.gridKetQuaNganhDaoTao);
            this.tabPage2.Controls.Add(this.btnAllNganh);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(779, 411);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "All Ngành";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnSelectNhieuHangNhieuCot
            // 
            this.btnSelectNhieuHangNhieuCot.Location = new System.Drawing.Point(7, 18);
            this.btnSelectNhieuHangNhieuCot.Name = "btnSelectNhieuHangNhieuCot";
            this.btnSelectNhieuHangNhieuCot.Size = new System.Drawing.Size(75, 23);
            this.btnSelectNhieuHangNhieuCot.TabIndex = 0;
            this.btnSelectNhieuHangNhieuCot.Text = "Truy vấn";
            this.btnSelectNhieuHangNhieuCot.UseVisualStyleBackColor = true;
            this.btnSelectNhieuHangNhieuCot.Click += new System.EventHandler(this.btnSelectNhieuHangNhieuCot_Click);
            // 
            // gridKetQua
            // 
            this.gridKetQua.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridKetQua.Location = new System.Drawing.Point(0, 47);
            this.gridKetQua.Name = "gridKetQua";
            this.gridKetQua.Size = new System.Drawing.Size(776, 361);
            this.gridKetQua.TabIndex = 1;
            // 
            // btnAllNganh
            // 
            this.btnAllNganh.Location = new System.Drawing.Point(6, 6);
            this.btnAllNganh.Name = "btnAllNganh";
            this.btnAllNganh.Size = new System.Drawing.Size(75, 23);
            this.btnAllNganh.TabIndex = 0;
            this.btnAllNganh.Text = "Truy Vấn";
            this.btnAllNganh.UseVisualStyleBackColor = true;
            this.btnAllNganh.Click += new System.EventHandler(this.btnAllNganh_Click);
            // 
            // gridKetQuaNganhDaoTao
            // 
            this.gridKetQuaNganhDaoTao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridKetQuaNganhDaoTao.Location = new System.Drawing.Point(0, 44);
            this.gridKetQuaNganhDaoTao.Name = "gridKetQuaNganhDaoTao";
            this.gridKetQuaNganhDaoTao.Size = new System.Drawing.Size(773, 364);
            this.gridKetQuaNganhDaoTao.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridKetQua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridKetQuaNganhDaoTao)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnSelectNhieuHangNhieuCot;
        private System.Windows.Forms.DataGridView gridKetQua;
        private System.Windows.Forms.DataGridView gridKetQuaNganhDaoTao;
        private System.Windows.Forms.Button btnAllNganh;
    }
}

