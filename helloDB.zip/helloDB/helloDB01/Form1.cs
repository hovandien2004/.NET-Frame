﻿using HelloDB01.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace helloDB01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelectNhieuHangNhieuCot_Click(object sender, EventArgs e)
        {
            #region 1. Tạo kết nối
            DbConnection cnn = new SqlConnection();
            //cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;User Id=sa;Password=123;";
            cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

            cnn.Open();
            #endregion

            #region 2. Tạo command
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
  SELECT MaSinhVien, HoTen, GioiTinhNam, NgaySinh, MaNganhDaoTao, GhiChu
    FROM SinhVien
ORDER BY MaNganhDaoTao
";
            #endregion

            #region 3. Thực thi command - trả về nhiều hàng, nhiều cột <-> DbDataReader
            DbDataReader dr = cmd.ExecuteReader();
            #endregion

            #region 4. Khai thác dữ liệu
            List<SinhVien> lst = new List<SinhVien>();
            while (dr.Read())
            {
                string maSinhVien = dr.GetString(0);
                string hoTen = dr.GetString(1);
                bool gioiTinhNam = dr.GetBoolean(2);

                DateTime? ngaySinh = null;

                // Cần phải bảo đảm dữ liệu ở cột có chỉ số 3 != NULL thì mới GetValue được
                if (dr.IsDBNull(3) == false)
                    ngaySinh = dr.GetDateTime(3);

                string maNganh = dr.GetString(4);
                string ghiChu = dr.GetString(5);

                SinhVien sv = new SinhVien()
                {
                    MaSinhVien = maSinhVien,
                    HoTen = hoTen,
                    GioiTinhNam = gioiTinhNam,
                    NgaySinh = ngaySinh,
                    MaNganhDaoTao = maNganh,
                    GhiChu = ghiChu
                };
                lst.Add(sv);
            }
            #endregion

            #region 5. Giải phóng tài nguyên
            dr.Close();
            cnn.Close();
            #endregion


            // Hiển thị danh sách vừa đọc được lên gridKetQua
            gridKetQua.AutoGenerateColumns = true;
            gridKetQua.DataSource = lst;
        }

        private void btnAllNganh_Click(object sender, EventArgs e)
        {
            #region 1. Tạo kết nối
            DbConnection cnn = new SqlConnection();
            //cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;User Id=sa;Password=123;";
            cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

            cnn.Open();
            #endregion

            #region 2. Tạo command
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
                                select MaNganhDaoTao, TenNganhDaoTao
                        from NganhDaoTao
                    ";
            #endregion

            #region 3. Thực thi command - trả về nhiều hàng, nhiều cột <-> DbDataReader
            DbDataReader dr = cmd.ExecuteReader();
            #endregion

            #region 4. Khai thác dữ liệu
            List<NganhDaoTao> lst = new List<NganhDaoTao>();
            while (dr.Read())
            {
                string maNganh = dr.GetString(0);
                string tenNganh = dr.GetString(1);
                NganhDaoTao nganhDT = new NganhDaoTao()
                {
                    MaNganhDaoTao = maNganh,
                    TenNganhDaoTao = tenNganh
                };
                lst.Add(nganhDT);
            }
            #endregion

            #region 5. Giải phóng tài nguyên
            dr.Close();
            cnn.Close();
            #endregion


            // Hiển thị danh sách vừa đọc được lên gridKetQua
            gridKetQuaNganhDaoTao.AutoGenerateColumns = true;
            gridKetQuaNganhDaoTao.DataSource = lst;
        }
    }
}
