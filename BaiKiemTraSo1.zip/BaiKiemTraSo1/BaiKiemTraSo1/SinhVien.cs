﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiKiemTraSo1
{
    internal class SinhVien
    {
        public string MaSinhVien { get; set; }
        public string TenSinhVien { get; set; }
        public bool GioiTinh { get; set; }
        public DateTime NgaySinh { get; set; }
        public double DiemTrungBinh { get; set; }

        public SinhVien(string maSinhVien, string tenSinhVien, bool gioiTinh, DateTime ngaySinh, double diemTrungBinh)
        {
            MaSinhVien = maSinhVien;
            TenSinhVien= tenSinhVien;
            GioiTinh = gioiTinh;
            NgaySinh = ngaySinh;
            DiemTrungBinh = diemTrungBinh;
        }
        public string GioiTinhToString
        {
           get { return GioiTinh ? "Nam" : "Nu"; }
        }
    }
}
