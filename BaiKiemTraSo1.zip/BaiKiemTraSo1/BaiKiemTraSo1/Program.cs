﻿using System.Collections.Generic;

namespace BaiKiemTraSo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<SinhVien> ds = new List<SinhVien>();
            string filename = "D:\\22t1020067\\BaiKiemTraSo1\\BaiKiemTraSo1\\sinhvien.txt";
            StreamReader sr = new StreamReader(filename);
            while (true)
            {
                string line = sr.ReadLine();
                if (line == null)
                    break;

                string[] ok = line.Split(',');
                string maSinhVien = ok[0];
                string tenSinhVien = ok[1];
                bool gioiTinh = ok[2] == "True";
                DateTime ngaySinh = DateTime.ParseExact(ok[3], "d/M/yyyy", null);
                double diemTrungBinh = double.Parse(ok[4]);

                SinhVien nv = new SinhVien(maSinhVien, tenSinhVien, gioiTinh, ngaySinh, diemTrungBinh);
                ds.Add(nv);
            }
            sr.Close();

            for (int i = 0; i < ds.Count - 1; i++)
                for (int j = i + 1; j < ds.Count; j++)
                    if (ds[i].DiemTrungBinh < ds[j].DiemTrungBinh)
                    {
                        SinhVien tmp = ds[i];
                        ds[i] = ds[j];
                        ds[j] = tmp;
                    }
            Console.WriteLine("{0,-5} {1,-15} {2,-20} {3,-15} {4,-15} {5,-15}", "STT", "Ma nhan vien", "Ho ten", "Gioi tinh", "Ngay sinh", "Diem trung binh");
            int stt = 1;
            for (int i = 0; i < ds.Count; i++)
            {              

                Console.WriteLine("{0,-5} {1,-15} {2,-20} {3,-15} {4,-15} {5,-15}", stt, ds[i].MaSinhVien, ds[i].TenSinhVien, ds[i].GioiTinhToString, ds[i].NgaySinh.ToString("dd/MM/yyyy"), ds[i].DiemTrungBinh);
                stt++;

            }
        }
    }
}
